SAMPLE SALE SKÅNE – SUPABASEVERSION

1. Öppna Supabase > SQL Editor > New query.
2. Klistra in innehållet i supabase-setup.sql och kör.
3. Skapa ditt admin-konto i Supabase Authentication > Users.
4. Publicera index.html och admin.html på ditt webbhotell/Vercel.
5. Besök /admin.html och logga in.

OBS: Publishable key får finnas i frontend. Lägg aldrig service_role/secret key i dessa filer.
