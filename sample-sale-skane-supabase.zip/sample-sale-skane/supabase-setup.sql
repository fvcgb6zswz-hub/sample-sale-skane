-- Kör hela detta block i Supabase > SQL Editor > New query
create table if not exists public.events (
 id uuid primary key default gen_random_uuid(),
 title text not null, brand text, date date not null, time text, city text not null, tag text, address text, link text, description text, published boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.members (
 id uuid primary key default gen_random_uuid(), email text not null, city text, interest text, created_at timestamptz not null default now()
);
alter table public.events enable row level security;
alter table public.members enable row level security;
drop policy if exists "Public read published events" on public.events;
create policy "Public read published events" on public.events for select using (published = true or auth.role() = 'authenticated');
drop policy if exists "Admin insert events" on public.events;
create policy "Admin insert events" on public.events for insert to authenticated with check (true);
drop policy if exists "Admin update events" on public.events;
create policy "Admin update events" on public.events for update to authenticated using (true) with check (true);
drop policy if exists "Admin delete events" on public.events;
create policy "Admin delete events" on public.events for delete to authenticated using (true);
drop policy if exists "Public join members" on public.members;
create policy "Public join members" on public.members for insert to anon, authenticated with check (true);
drop policy if exists "Admin read members" on public.members;
create policy "Admin read members" on public.members for select to authenticated using (true);
